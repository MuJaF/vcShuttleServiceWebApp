﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using VCShuttle.Data;
using VCShuttle.Models;
using VCShuttle.Services;
using AuthorizeAttribute = Microsoft.AspNetCore.Authorization.AuthorizeAttribute;

namespace VCShuttle.Controllers
{
    
    public class BookingsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private static List<Bookings> bookings = new List<Bookings>(); // Simulating data storage
        private static Dictionary<string, int> bookedSlotsCount = new Dictionary<string, int>();


        public BookingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Admin")]
        // GET: Bookings/Index
        public async Task<IActionResult> Index()
        {
            return _context.Bookings != null ?
                        View(await _context.Bookings.ToListAsync()) :
                        Problem("Entity set 'ApplicationDbContext.Bookings'  is null.");
        }

        [Authorize(Roles = "Student")]
        // GET: Bookings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Bookings booking)
        {
            if (ModelState.IsValid)
            {
                var currentTime = DateTime.UtcNow; // Get the current time in UTC

                // Check if the time slot has reached the maximum bookings (12 in this case) for the specific location
                var bookedCountForLocation = _context.Bookings.Count(b => b.Time == booking.Time && b.Location == booking.Location);

                if (bookedCountForLocation >= 12)
                {
                    ModelState.AddModelError("Time", "No more seats available for this time slot at this location.");
                    return View(booking); // Display the view with the error message
                }

                // Check if the total bookings for this time slot across all locations have reached the maximum limit
                var totalBookedCount = _context.Bookings.Count(b => b.Time == booking.Time);

                if (totalBookedCount >= 24) // Assuming two locations, each with a limit of 12 bookings per time slot
                {
                    ModelState.AddModelError("Time", "No more seats available for this time slot.");
                    return View(booking); // Display the view with the error message
                }

                // Calculate the time left for departure
                // Parse the selected time from the dropdown
                var selectedTime = TimeSpan.Parse(booking.Time.Replace(" AM", "").Replace(" PM", ""));

                // Get hours and minutes from the selected time
                var selectedHours = selectedTime.Hours;
                var selectedMinutes = selectedTime.Minutes;

                // Calculate the departure time using the current date and the selected time
                var departureTime = new DateTime(currentTime.Year, currentTime.Month, currentTime.Day, selectedHours, selectedMinutes, 0);

                // Calculate the time left for departure
                var timeLeft = departureTime - currentTime;

                TempData["TimeLeft"] = timeLeft.ToString(@"hh\:mm\:ss"); // Store the time left in TempData as string

                _context.Bookings.Add(booking);
                _context.SaveChanges();

            }

            return View(booking);
        }

        private DateTime GetDepartureTime(string selectedTime)
        {
            // Parse the selectedTime string to extract hours and minutes
            var timeParts = selectedTime.Split(':');
            var selectedHours = int.Parse(timeParts[0]);
            var selectedMinutes = int.Parse(timeParts[1]);

            // Get the current time in UTC
            var currentTime = DateTime.UtcNow;

            // Calculate departure time based on the selected time and the user's current time
            var departureDateTime = currentTime.Date
                .AddHours(selectedHours)
                .AddMinutes(selectedMinutes);

            // Adjust departure time logic if necessary (considering travel duration, etc.)

            return departureDateTime;
        }



        private string GetShuttleInfo(string time)
        {
            string shuttleInfo = string.Empty;

            using (var dbContext = new ApplicationDbContext())
            {
                var shuttleData = _context.ShuttleInfos.FirstOrDefault(s => s.TimeSlot == time);

                if (shuttleData != null)
                {
                    shuttleInfo = shuttleData.Info;
                }
            }

            return shuttleInfo;
        }

        [Authorize(Roles = "Admin")]
        // GET: Bookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Bookings == null)
            {
                return NotFound();
            }

            var bookings = await _context.Bookings
                .FirstOrDefaultAsync(m => m.BookingID == id);
            if (bookings == null)
            {
                return NotFound();
            }

            return View(bookings);
        }


        [Authorize(Roles = "Admin")]
        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Bookings == null)
            {
                return NotFound();
            }

            var bookings = await _context.Bookings.FindAsync(id);
            if (bookings == null)
            {
                return NotFound();
            }
            return View(bookings);
        }

        // POST: Bookings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingID,Location,Time")] Bookings bookings)
        {
            if (id != bookings.BookingID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bookings);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookingsExists(bookings.BookingID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bookings);
        }

        [Authorize(Roles = "Admin")]
        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Bookings == null)
            {
                return NotFound();
            }

            var bookings = await _context.Bookings
                .FirstOrDefaultAsync(m => m.BookingID == id);
            if (bookings == null)
            {
                return NotFound();
            }

            return View(bookings);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Bookings == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Bookings'  is null.");
            }
            var bookings = await _context.Bookings.FindAsync(id);
            if (bookings != null)
            {
                _context.Bookings.Remove(bookings);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookingsExists(int id)
        {
          return (_context.Bookings?.Any(e => e.BookingID == id)).GetValueOrDefault();
        }
    }
}
