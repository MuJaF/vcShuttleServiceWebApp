﻿using System.Text.RegularExpressions;
using Microsoft.AspNet.SignalR;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using VCShuttle.Data;
using AuthorizeAttribute = Microsoft.AspNetCore.Authorization.AuthorizeAttribute;

namespace VCShuttle.Controllers
{
    //public class ShuttleHub : Hub
    //{
    //    // Method to broadcast real-time shuttle data to all connected clients
    //    public async Task UpdateShuttleData(dynamic shuttleData)
    //    {
    //        // Broadcast the shuttle data to all connected clients in the "UpdateShuttleData" group
    //        await Clients.All.updateShuttleData(shuttleData);
    //    }

    //    // Method to add clients to a SignalR group (optional)
    //    public async Task JoinShuttleGroup(string groupName)
    //    {
    //        await Groups.Add(Context.ConnectionId, groupName);
    //    }

    //    // Method to remove clients from a SignalR group (optional)
    //    public async Task LeaveShuttleGroup(string groupName)
    //    {
    //        await Groups.Remove(Context.ConnectionId, groupName);
    //    }


    //    ////////////////////////////////
    //    private readonly ApplicationDbContext _dbContext;

    //    public ShuttleHub(ApplicationDbContext dbContext)
    //    {
    //        _dbContext = dbContext;
    //    }

    //    // Method to send real-time shuttle data to clients
    //    public async Task SendShuttleDataUpdates()
    //    {
    //        var shuttleData = await _dbContext.ShuttleData.ToListAsync();
    //        Clients.All.updateShuttleData(shuttleData);
    //    }
    //}
}