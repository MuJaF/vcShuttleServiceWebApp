﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using VCShuttle.Data;
using VCShuttle.Models;
using AuthorizeAttribute = Microsoft.AspNetCore.Authorization.AuthorizeAttribute;

namespace VCShuttle.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ReportsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReportsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult DailyStatistics()
        {
            var today = DateTime.Today;
            var tomorrow = today.AddDays(1);

            var dailyBookingsCount = _context.Bookings
                .AsEnumerable()
                .Where(b =>
                {
                    var timePart = b.Time.Split(' ')[0];
                    return DateTime.TryParseExact(timePart, "h:mm tt", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedTime) &&
                        parsedTime >= today && parsedTime < tomorrow;
                })
                .Sum(b => b.Count);

            // Fetch the total count of bookings for the day and pass it to the view
            var totalBookingsForTheDay = _context.Bookings
                .AsEnumerable()
                .Count(b =>
                {
                    var timePart = b.Time.Split(' ')[0];
                    return DateTime.TryParseExact(timePart, "h:mm tt", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedTime) &&
                        parsedTime >= today && parsedTime < tomorrow;
                });

            ViewBag.TotalBookingsForTheDay = totalBookingsForTheDay;

            return View(dailyBookingsCount);
        }


        public IActionResult AdminDashboard()
        {
            var mostBookedTimeByLocation = GetMostBookedTimeByLocation();
            return View(mostBookedTimeByLocation);
        }

        private List<Bookings> GetMostBookedTimeByLocation()
        {
            var mostBookedTimeByLocation = _context.Bookings
                .GroupBy(b => new { b.Time, b.Location })
                .Select(g => new Bookings
                {
                    Time = g.Key.Time,
                    Location = g.Key.Location,
                    Count = g.Count()
                })
                .OrderByDescending(b => b.Count)
                .ToList();

            return mostBookedTimeByLocation;
        }
    }
}