﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using VCShuttle.Controllers;
using VCShuttle.Models;

namespace VCShuttle.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<VCShuttle.Models.Students>? Students { get; set; }
        public DbSet<VCShuttle.Models.Bookings>? Bookings { get; set; }
        public DbSet<VCShuttle.Models.ShuttleInfo> ShuttleInfos { get; set; }
        public DbSet<Bookings> DailyBookingCounts { get; internal set; }
        //public DbSet<ShuttleData> ShuttleData { get; set; }
    }
}