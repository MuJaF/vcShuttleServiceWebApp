﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;
using VCShuttle.Data;
using VCShuttle.Models;

namespace CodeBlock.Utils
{
    public static class DBCreator
    {
        private static bool _isFistTime = true;

        public async static void Init(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.CreateScope())
            {
                await SeedData(serviceScope.ServiceProvider.GetService<ApplicationDbContext>(),
                    serviceScope.ServiceProvider.GetService<UserManager<IdentityUser>>(),
                    serviceScope.ServiceProvider.GetService<RoleManager<IdentityRole>>());
            }
        }

        public static async Task SeedData(ApplicationDbContext context, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            System.Console.WriteLine("Migration inprogress...");

            context.Database.Migrate();
            if (_isFistTime)
            {
                IdentityRole[] roles = new IdentityRole[3];
                roles[0] = new IdentityRole() { Name = "Admin" };
                roles[1] = new IdentityRole() { Name = "Student" };
                roles[2] = new IdentityRole() { Name = "Driver" };

                int counter = 0;
                for (int i = 0; i < roles.Length; i++)
                {
                    var foundRole = await roleManager.RoleExistsAsync(roles[i].Name);

                    if (!foundRole)
                    {

                        var result = await roleManager.CreateAsync(roles[i]);
                        if (result.Succeeded)
                        {
                            counter++;
                            Console.WriteLine("New role added: " + roles[i].Name);
                        }
                    }
                }
                var email = "Admin@vcconnect.edu.za";
                var admin = context.Users.FirstOrDefault(x => x.UserName == email);

                if (admin == null)
                {

                    IdentityUser identityUser = new IdentityUser();                  
                    identityUser.Email = email;
                    identityUser.UserName = email; 
                    identityUser.EmailConfirmed = true;
                    await userManager.CreateAsync(identityUser);

                    IdentityUser createdUser = await userManager.FindByNameAsync(email);
                    await userManager.AddPasswordAsync(createdUser, "Admin@123");
                    //await _userManager.ConfirmEmailAsync(createdUser, createdUser.Id);
                    var adminUser = createdUser;
                    if (adminUser != null)
                    {
                        var adminResult = await userManager.AddToRoleAsync(createdUser, "Admin");

                        if (adminResult != null)
                        {
                            Console.WriteLine("Admin account created!");
                        }
                    }
                    
                    context.SaveChanges(); 
                }

            }

            _isFistTime = false;

            System.Console.WriteLine("Migration completed");
        }        
    }
}