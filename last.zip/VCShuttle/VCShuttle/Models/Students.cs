﻿using System.ComponentModel.DataAnnotations;

namespace VCShuttle.Models
{
    public class Students
    {
        [Key]
        public int StudentID { get; set; }
        public  string Email { get; set; }
        public string Password { get; set; }

    }
}
