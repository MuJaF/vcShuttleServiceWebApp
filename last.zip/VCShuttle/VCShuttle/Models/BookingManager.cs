﻿using System;
using System.Collections.Generic;
using System.Linq;
using VCShuttle.Models;

namespace VCShuttle.Services
{
    public static class BookingManager
    {
        private static List<Bookings> bookings = new List<Bookings>();
        private static Dictionary<string, int> bookedSlotsCount = new Dictionary<string, int>();

        public static bool AddBooking(Bookings booking)
        {
            bookings.Add(booking);

            if (bookedSlotsCount.ContainsKey(booking.Time))
            {
                bookedSlotsCount[booking.Time]++;
            }
            else
            {
                bookedSlotsCount.Add(booking.Time, 1);
            }

            return CheckAndDepartShuttle(booking.Time);
        }

        private static bool CheckAndDepartShuttle(string time)
        {
            if (bookedSlotsCount.ContainsKey(time) && bookedSlotsCount[time] >= 6)
            {
                DepartShuttle(time);
                return true;
            }
            return false;
        }

        private static void DepartShuttle(string time)
        {
            // Replace this with your logic to actually depart the shuttle
            Console.WriteLine($"Shuttle departure for {time} slot as minimum seats reached.");
            // Here you could trigger an actual action to depart the shuttle
        }

        public static List<Bookings> GetAllBookings()
        {
            return bookings;
        }
    }
}
