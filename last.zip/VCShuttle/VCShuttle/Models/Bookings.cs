﻿using System.ComponentModel.DataAnnotations;


namespace VCShuttle.Models
{
    public class Bookings
    {
        [Key]   
        public int BookingID { get; set; }
        public String Location { get; set; }
        public String Time { get; set; }
       public int Count { get; set; }

    }
}
