﻿using Microsoft.AspNetCore.Identity;

namespace VCShuttle.Models
{
    public class ApplicationUser : IdentityUser
    {

    }
}
