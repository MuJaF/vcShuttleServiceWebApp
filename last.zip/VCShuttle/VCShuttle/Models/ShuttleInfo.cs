﻿using System.ComponentModel.DataAnnotations;

namespace VCShuttle.Models
{
    public class ShuttleInfo
    {
        [Key]
        public int Id { get; set; }

        public string TimeSlot { get; set; }

        public string Info { get; set; }
    }
}
