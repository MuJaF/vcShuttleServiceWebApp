﻿namespace VCShuttle.Models
{
    public class AdminDashboardModel
    {
        public int TotalBookings { get; set; }
        public List<Bookings> BookingsPerLocation { get; set; }
        // Other properties for statistics...
    }

}
